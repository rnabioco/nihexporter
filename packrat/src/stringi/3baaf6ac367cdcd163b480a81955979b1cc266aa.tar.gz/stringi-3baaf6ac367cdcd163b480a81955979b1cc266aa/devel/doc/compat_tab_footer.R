cat('<div class="footer">')
cat('<a rel="license" href="http://creativecommons.org/licenses/by/3.0/">')
cat('<img alt="Creative Commons License" style="border-width:0; float: left; margin: 8px" src="http://i.creativecommons.org/l/by/3.0/88x31.png"></a>')
cat('<a href="http://www.rexamine.com/">
<img style="float: right; margin: 8px"
src="http://static.rexamine.com/img/Rexamine_logo_transparent3.png" title="Rexamine" alt="Rexamine" /></a>')

cat('<div style="text-align: center">Licensed under the
<a rel="license" href="http://creativecommons.org/licenses/by/3.0/">Creative
Commons Attribution 3.0 Unported License</a>.<br />')
cat('Copyleft 2013-2014, <a href="http://gagolewski.rexamine.com">Marek Gagolewski</a>.<br />')
cat('Last updated: ', as.character(Sys.time()), '</div>')
cat('</div>')
