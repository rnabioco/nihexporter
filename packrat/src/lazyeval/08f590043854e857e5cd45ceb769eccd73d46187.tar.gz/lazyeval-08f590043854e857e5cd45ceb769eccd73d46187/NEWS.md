# lazyeval 0.1.10.9000

* Fixed an infinite loop in `lazy_dots(.follow_symbols = TRUE)` (#22, #24)

# lazyeval 0.1.10

* `as.lazy_dots()` gains a method for NULL, returning a zero-length
  list.

* `auto_names()` no longer truncates symbols (#19, #20)
