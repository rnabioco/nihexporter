#' Fast and friendly string manipulation.
#'
#' @name stringr
#' @import stringi
NULL
